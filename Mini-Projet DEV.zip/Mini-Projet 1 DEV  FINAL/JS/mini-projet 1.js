//declaration des different variable
const toggleBtn = document.querySelector('#ajt');
const toggleBtn2 = document.querySelector('#cv');
const toggleBtn3 = document.querySelector('#event');
const toggleBtn4 = document.querySelector('#Home');
const toggleBtn5 = document.querySelector('#btnimage1');
const toggleBtn6 = document.querySelector('#btnimage2');
const toggleBtn7 = document.querySelector('#btnimage3');
const toggleBtn8 = document.querySelector('.btnback1');
const toggleBtn9 = document.querySelector('.btnback2');
const toggleBtn10 = document.querySelector('.btnback3');
const toggleBtn11 = document.querySelector('#About');
const toggleBtn12 = document.querySelector('#Maroc');
const toggleBtn13 = document.querySelector('#Turquie');
const toggleBtn14 = document.querySelector('#Russie');
const divList   = document.querySelector('.form');
const divList2   = document.querySelector('.form2');
const divList3   = document.querySelector('.home0');
const divList4   = document.querySelector('.article1');
const divList5   = document.querySelector('.article2');
const divList6   = document.querySelector('.article3');
const divList7   = document.querySelector('.about');
const divList8   = document.querySelector('.Maroc');
const divList9   = document.querySelector('.Turquie');
const divList10  = document.querySelector('.Russie');
const tab       = document.querySelector('.list');
const btn2      = document.querySelector('.eng');
const side      = document.querySelector('#side');
const topbody1  = document.querySelector('#topbody1');
const topbody   = document.querySelector('#topbody');
const backto    = document.querySelector('#backto');



//fonction pour le button principal de ajouter
toggleBtn.addEventListener('click',() => {
  
  if(divList.style.display === 'block'){
    divList.style.display = 'none';
  } else {  
    divList.style.display = 'block';
    toggleBtn.style.display='none'
    tab.style.display = 'none'
    backto.style.display='block';
  }
});
//fonction pour le button back sur la formulaire
backto.addEventListener('click',() => {
  
  if(divList.style.display = 'block'){
    divList.style.display = 'none';
    toggleBtn.style.display='block'
    tab.style.display = 'inline-table'
    backto.style.display='none';
}
});
//fonction pour formulaire CV
toggleBtn2.addEventListener('click',() => {
  
  if(divList2.style.display === 'block'){
    divList2.style.display = 'none';
    divList3.style.display = 'block';
    topbody1.style.display = 'none';
    
  } else {  
    divList2.style.display = 'block';
    divList3.style.display = 'none';
    divList4.style.display = 'none';
    divList5.style.display = 'none';
    divList6.style.display = 'none';
    divList7.style.display = 'none';
    topbody1.style.display = 'none';
    divList8.style.display = 'none';
    divList9.style.display = 'none';
    divList10.style.display = 'none';
  }
});
//fonction pour afficher le tableau
toggleBtn3.addEventListener('click',() => {
  
  if(topbody1.style.display === 'block'){
    topbody1.style.display = 'none';
    divList3.style.display = 'block';
    divList2.style.display = 'none';
  } else {  
    topbody1.style.display = 'block';
    divList3.style.display = 'none';
    divList2.style.display = 'none';
    divList4.style.display = 'none';
    divList5.style.display = 'none';
    divList6.style.display = 'none';
    divList7.style.display = 'none';
    divList8.style.display = 'none';
    divList9.style.display = 'none';
    divList10.style.display = 'none';
  }
});

//fonction pour Home
toggleBtn4.addEventListener('click',() => {
  
  if(divList3.style.display === 'block'){
    topbody1.style.display = 'none';
    divList3.style.display = 'block';
    divList2.style.display = 'none';
  } else {  
    topbody1.style.display = 'none';
    divList3.style.display = 'block';
    divList2.style.display = 'none';
    divList7.style.display = 'none';
    divList4.style.display = 'none';
    divList5.style.display = 'none';
    divList6.style.display = 'none';
    divList8.style.display = 'none';
    divList9.style.display = 'none';
    divList10.style.display = 'none';
    
  }
});

//fonction pour afficher l'article1
toggleBtn5.addEventListener('click',() => {
  
  if(divList4.style.display === 'block'){
    divList4.style.display = 'none';
    divList3.style.display = 'block';
    divList2.style.display = 'none';
  } else {  
    topbody1.style.display = 'none';
    divList4.style.display = 'block';
    divList3.style.display = 'none';
    divList2.style.display = 'none';
    divList5.style.display = 'none';
    divList6.style.display = 'none';
    divList7.style.display = 'none';
    divList8.style.display = 'none';
    divList9.style.display = 'none';
    divList10.style.display = 'none';

  }
});

//fonction pour afficher l'article2
toggleBtn6.addEventListener('click',() => {
  
  if(divList5.style.display === 'block'){
    divList5.style.display = 'none';
    divList3.style.display = 'block';
    divList2.style.display = 'none';
  } else {  
    topbody1.style.display = 'none';
    divList5.style.display = 'block';
    divList3.style.display = 'none';
    divList2.style.display = 'none';
    divList6.style.display = 'none';
    divList4.style.display = 'none';
    divList7.style.display = 'none';
    divList8.style.display = 'none';
    divList9.style.display = 'none';
    divList10.style.display = 'none';
  }
});

//fonction pour afficher l'article3
toggleBtn7.addEventListener('click',() => {
  
  if(divList6.style.display === 'block'){
    divList6.style.display = 'none';
    divList3.style.display = 'block';
    divList2.style.display = 'none';
  } else {  
    topbody1.style.display = 'none';
    divList6.style.display = 'block';
    divList3.style.display = 'none';
    divList2.style.display = 'none';
    divList5.style.display = 'none';
    divList4.style.display = 'none';
    divList7.style.display = 'none';
    divList8.style.display = 'none';
    divList9.style.display = 'none';
    divList10.style.display = 'none';
  }
});

//fonction pour afficher la partie about us
toggleBtn11.addEventListener('click',() => {
  
  if(divList7.style.display === 'block'){
    divList7.style.display = 'none';
    divList3.style.display = 'block';
    divList2.style.display = 'none';
  } else {  
    topbody1.style.display = 'none';
    divList7.style.display = 'block';
    divList3.style.display = 'none';
    divList2.style.display = 'none';
    divList5.style.display = 'none';
    divList6.style.display = 'none';
    divList8.style.display = 'none';
    divList9.style.display = 'none';
    divList10.style.display = 'none';
  }
});

//fonction pour afficher la partie maroc dans le menu
toggleBtn12.addEventListener('click',() => {
  
  if(divList8.style.display === 'block'){
    divList8.style.display = 'none';
    divList3.style.display = 'block';
    divList2.style.display = 'none';
  } else {  
    topbody1.style.display = 'none';
    divList8.style.display = 'block';
    divList3.style.display = 'none';
    divList2.style.display = 'none';
    divList5.style.display = 'none';
    divList6.style.display = 'none';
    divList7.style.display = 'none';
    divList9.style.display = 'none';
    divList10.style.display = 'none';
  }
});


//fonction pour afficher la partie turque dans le menu
toggleBtn13.addEventListener('click',() => {
  
  if(divList9.style.display === 'block'){
    divList9.style.display = 'none';
    divList3.style.display = 'block';
    divList2.style.display = 'none';
  } else {  
    topbody1.style.display = 'none';
    divList9.style.display = 'block';
    divList3.style.display = 'none';
    divList2.style.display = 'none';
    divList5.style.display = 'none';
    divList6.style.display = 'none';
    divList7.style.display = 'none';
    divList8.style.display = 'none';
    divList10.style.display = 'none';
  }
});

//fonction pour afficher la partie Russie dans le menu
toggleBtn14.addEventListener('click',() => {
  
  if(divList10.style.display === 'block'){
    divList10.style.display = 'none';
    divList3.style.display = 'block';
    divList2.style.display = 'none';
  } else {  
    topbody1.style.display = 'none';
    divList10.style.display = 'block';
    divList3.style.display = 'none';
    divList2.style.display = 'none';
    divList5.style.display = 'none';
    divList6.style.display = 'none';
    divList7.style.display = 'none';
    divList9.style.display = 'none';
    divList8.style.display = 'none';
  }
});

//fonction pour le button back sur l'article 1
toggleBtn8.addEventListener('click',() => {
  
  if(divList4.style.display = 'block'){
    divList4.style.display = 'none';
    divList3.style.display = 'block' 
}
});

//fonction pour le button back sur l'article 2
toggleBtn9.addEventListener('click',() => {
  
  if(divList5.style.display = 'block'){
    divList5.style.display = 'none';
    divList3.style.display = 'block' 
}
});

//fonction pour le button back sur l'article 3
toggleBtn10.addEventListener('click',() => {
  
  if(divList6.style.display = 'block'){
    divList6.style.display = 'none';
    divList3.style.display = 'block' 
}
});




//fonction pour enregistrer les information
var selectedRow = null

function onFormSubmit() {
    if (divList.style.display = 'block'  ) {
          var formData = readFormData();
          divList.style.display = 'none';
          toggleBtn.style.display='block';
          tab.style.display = 'inline-table';
          backto.style.display='none';

             if (selectedRow == null){
            insertNewRecord(formData);
            resetForm();}
        else{
            updateRecord(formData);
            resetForm();
          }
        
    }
}

//recuperation des donnes de la formulaire
function readFormData() {
  var formData = {};
  formData["agNAV"] = document.getElementById("agNAV").value;
  formData["agELT1"] = document.getElementById("agELT1").value;
  formData["agELT2"] = document.getElementById("agELT2").value;
  formData["agELT3"] = document.getElementById("agELT3").value;
  formData["agELT4"] = document.getElementById("agELT4").value;
  return formData;
}

//l'ajoute des donnes au tableau
function insertNewRecord(data) {
  var table = document.getElementById("agenceList").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.length);
  cell1 = newRow.insertCell(0);
  cell1.innerHTML = data.agNAV;
  cell2 = newRow.insertCell(1);
  cell2.innerHTML = data.agELT1;
  cell3 = newRow.insertCell(2);
  cell3.innerHTML = data.agELT2;
  cell4 = newRow.insertCell(3);
  cell4.innerHTML = data.agELT3;
  cell5 = newRow.insertCell(4);
  cell5.innerHTML = data.agELT4;
  cell6 = newRow.insertCell(5);
  cell6.innerHTML = `<a style="color: white; padding: 8px 5px;background: #0da1bb;border: 0;outline: none;border-radius: 3px;font-size: 15px;font-weight: bold;margin-top: 5px;position: static;text-align: center;"  onClick="onEdit(this)">Edit</a>
                     <a style="color: white; padding: 8px 5px;background:red ;border: 0; outline: none;border-radius: 3px;font-size: 15px;font-weight: bold;margin-top: 5px;position: static;text-align: center;" onClick="onDelete(this)">Delete</a>`;
}

//fct pour entrer les modifications
function onEdit(td) {
  if(divList.style.display = 'none'){
  divList.style.display = 'block'
  toggleBtn.style.display='none';
  tab.style.display = 'none';
  backto.style.display='block';
  selectedRow = td.parentElement.parentElement;
  document.getElementById("agNAV").value = selectedRow.cells[0].innerHTML;
  document.getElementById("agELT1").value = selectedRow.cells[1].innerHTML;
  document.getElementById("agELT2").value = selectedRow.cells[2].innerHTML;
  document.getElementById("agELT3").value = selectedRow.cells[3].innerHTML;
  document.getElementById("agELT4").value = selectedRow.cells[3].innerHTML;
}
}

//fct pour appliquer les modifications entres
function updateRecord(formData) {
  selectedRow.cells[0].innerHTML = formData.agNAV;
  selectedRow.cells[1].innerHTML = formData.agELT1;
  selectedRow.cells[2].innerHTML = formData.agELT2;
  selectedRow.cells[3].innerHTML = formData.agELT3;
  selectedRow.cells[4].innerHTML = formData.agELT4; 
}

//fct pour supprimer les premiers donnees
function resetForm() {
  document.getElementById("agNAV").value = "";
  document.getElementById("agELT1").value = "";
  document.getElementById("agELT2").value = "";
  document.getElementById("agELT3").value = "";
  document.getElementById("agELT4").value = "";

  selectedRow = null;
}

//fct pour supprimer les lignes
function onDelete(td) {
  if (confirm('Êtes-vous sûr de vouloir supprimer ce ligne?')) {
      row = td.parentElement.parentElement;
      document.getElementById("agenceList").deleteRow(row.rowIndex);
      resetForm();
  }
}

// fonction qui permet de zoomer les images
mediumZoom('.zoom', {
  margin:50

});


